# As of 1/9/2025, BATTinfo is discontinued as it is officially completed.

BATTinfo is a simple batch script that shows some info about the battery installed in your laptop, and allows you to generate a report with in-depth battery info.


Too much clutter? Get this instead! https://github.com/bladestech/BATTinfo-Classic


